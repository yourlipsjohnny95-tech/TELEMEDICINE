# SehatLab (Python / Flask)

## Cara menjalankan
1. Pasang Python 3.9+.
2. Di folder ini: `pip install -r requirements.txt`
3. Jalankan: `python app.py`
4. Buka http://127.0.0.1:5000 (demo: isi email dan kata sandi apa saja, minimal 6 karakter)

## Struktur
- `app.py` : server Flask
- `public/index.html` : tampilan aplikasi (sama persis dengan versi sebelumnya)
- `requirements.txt` : dependensi
