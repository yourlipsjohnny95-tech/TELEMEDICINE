"""SehatLab - aplikasi web kesehatan (server Python / Flask).

Jalankan:  python app.py   lalu buka  http://127.0.0.1:5000
"""
import os
from pathlib import Path

from flask import Flask, send_from_directory

BASE = Path(__file__).resolve().parent
PUBLIC = BASE / "public"

app = Flask(__name__, static_folder=None)


@app.route("/")
def beranda():
    # Tampilan (HTML/CSS/JS) disajikan apa adanya agar hasilnya sama persis.
    return send_from_directory(PUBLIC, "index.html")


@app.route("/health")
def health():
    return {"status": "ok"}


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
